//Reham Wahbi

const express = require('express');
const app = express();
const bcrypt = require("bcrypt");
const loginRoutes = require("./routes/login");
const addproductRoutes = require("./routes/addproduct");
const editproductRoutes = require("./routes/editproduct");
const deleteproductRoutes = require("./routes/deleteproduct");
const productListRoutes = require("./routes/productList");
const productDetailsRoutes = require("./routes/productDetails")
const contactRoutes = require("./routes/contactus");
const signupRoutes = require("./routes/signup");
const profileRoutes = require('./routes/myProfile');

const session = require("express-session");
const cors = require('cors');
app.use(cors({ origin: "http://localhost:3000", credentials: true }));
app.use(
  session({
    secret: "my_secret_key",
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false, httpOnly: true },
  })
);


const port = 5000;
app.use("/uploads", express.static("uploads"));
app.use(express.json());
app.use('/signup', signupRoutes);
app.use('/login', loginRoutes);
app.use('/addproduct', addproductRoutes);
app.use('/editproduct', editproductRoutes);
app.use('/productlist', productListRoutes);
app.use('/productdetails', productDetailsRoutes);
app.use('/contact', contactRoutes);
app.use('/myprofile', profileRoutes);
app.get("/", (req, res) => {
  res.send("Server is working");
});

//app.use('/contactus', contactRoutes);
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({
    error: 'Internal Server Error',
    message: err.message,
  });
});

app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
