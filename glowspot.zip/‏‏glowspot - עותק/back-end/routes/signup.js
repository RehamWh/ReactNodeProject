const express = require('express');
const router = express.Router();
const dbSingleton = require('../dbSingleton');
const bcrypt = require("bcrypt");
const cors = require('cors');
router.use(cors()); // Enable CORS for all origins

// Get database connection
const db = dbSingleton.getConnection();

router.post('/', async (req, res) => {
  const { name, last_name, phone_number, email, date_of_birth, user_name, password, confirmpassword } = req.body;

  if (!user_name || !name || !last_name || !password) {
    return res.status(400).json({ error: "All fields are required" });
  }

  if (password !== confirmpassword) {
    return res.status(400).json({ error: "Passwords do not match" });
  }

  const hashedPassword = await bcrypt.hash(password, 10);

  const query = 'INSERT INTO users (name, last_name, phone_number, email, date_of_birth, user_name, password_hash, user_role) VALUES (?,?,?,?,?,?,?, "user")';
  db.query(query, [name, last_name, phone_number, email, date_of_birth, user_name, hashedPassword], (err, results) => {
    if (err) {
      console.error("Database Error:", err);
      res.status(500).json({ error: "Database error", details: err.message });
      return;
    }
    res.json({ message: "User registered successfully!", id: results.insertId });
  });
});

module.exports = router;