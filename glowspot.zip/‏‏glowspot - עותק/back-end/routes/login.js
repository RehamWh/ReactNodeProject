const express = require('express'); // Express framework for handling routes
const router = express.Router(); // Router for defining login routes
const dbSingleton = require('../dbSingleton'); // Database connection singleton
const bcrypt = require('bcrypt'); // Bcrypt for password hashing and comparison
const cors = require('cors'); // CORS for cross-origin requests
const session = require('express-session'); // Session management

// Database connection
const db = dbSingleton.getConnection();

router.post("/", async (req, res) => {
  const { user_name, password } = req.body;
  if (!user_name || !password) {
    return res.status(400).json({ error: "Insert user name and password" });
  }

  const query = "SELECT * FROM users WHERE user_name = ?";
  db.query(query, [user_name], async (err, results) => {
    if (err) {
      console.error("Database error:", err);
      return res.status(500).json({ error: "Database error", details: err });
    }

    if (results.length === 0) {
      console.log("User not found:", user_name);
      return res.status(400).json({ error: "User not found!" });
    }

    const user = results[0];
    console.log("User found:", user); // ✅ Log user data for debugging

    try {
      const isMatch = await bcrypt.compare(password, user.password_hash);
      if (!isMatch) {
        console.log("Password mismatch for user:", user_name);
        return res.status(400).json({ error: "Invalid username or password" });
      }

      req.session.user = { id: user.id, user_name: user.user_name, role: user.role };
      res.json({ message: "Successfully logged in!", user: req.session.user });

    } catch (error) {
      console.error("Password comparison error:", error);
      res.status(500).json({ error: "Server error during login" });
    }
  });
});
module.exports = router;