const express = require('express');
const router = express.Router();
const dbSingleton = require('../dbSingleton');
const db = dbSingleton.getConnection();
const multer = require("multer");
const path = require("path");
const cors = require('cors');
router.use(cors()); // Enable CORS for all origins


// Multer setup for handling file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, "uploads/"); // Ensure this folder exists
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + path.extname(file.originalname)); // Unique filename
  },
});

const upload = multer({ storage: storage });

router.put('/:id', upload.single('image'), (req, res) => {
  const { id } = req.params;
  const { name, price, description } = req.body;

  // Handle uploaded image path
  let image = null;
  if (req.file) {
    image = `/uploads/${req.file.filename}`;
  }

  if (!name || !price || !description) {
    return res.status(400).json({ message: 'Name, price, and description are required!' });
  }

  // Query to update product
  let query = 'UPDATE products SET name = ?, price = ?, description = ? WHERE id = ?';
  let values = [name, price, description, id];

  if (image) {
    query = 'UPDATE products SET name = ?, price = ?, description = ?, image = ? WHERE id = ?';
    values = [name, price, description, image, id];
  }

  db.query(query, values, (err, results) => {
    if (err) {
      return res.status(500).send(err);
    }
    res.json({ message: 'Product updated successfully!' });
  });
});

module.exports = router;
