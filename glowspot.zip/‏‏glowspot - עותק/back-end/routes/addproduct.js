const express = require('express');
const router = express.Router();
const dbSingleton = require('../dbSingleton');
const db = dbSingleton.getConnection();
const multer = require('multer');
const path = require('path');
const cors = require('cors');
router.use(cors()); // Enable CORS for all origins

// Multer storage configuration
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, "uploads/"); // Ensure this folder exists
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + path.extname(file.originalname)); // Unique filename
  },
});

const upload = multer({ storage: storage });

router.post('/', upload.single('image'), (req, res) => {
  const { name, price, description } = req.body;

  if (!name || !price || !description) {
    return res.status(400).json({ message: "Name, price, and description are required!" });
  }

  if (!req.file) {
    return res.status(400).json({ message: "Image file is required!" });
  }

  const imageUrl = `/uploads/${req.file.filename}`;
  const query = 'INSERT INTO products (name, price, description, image) VALUES (?, ?, ?, ?)';

  db.query(query, [name, price, description, imageUrl], (err, results) => {
    if (err) {
      return res.status(500).json({ message: "Database error", error: err });
    }

    res.json({
      message: 'Product added successfully!',
      product: {
        id: results.insertId,
        name,
        price,
        description,
        image: imageUrl,
      },
    });
  });
});

module.exports = router;
