const express = require("express");
const cors = require("cors");
const router = express();
router.use(cors());
router.use(express.json());

const dbSingleton = require('../dbSingleton');
const db = dbSingleton.getConnection();

router.post("/", (req, res) => {
  const { name, email, message } = req.body;

  // Validate the incoming request
  if (!name || !email || !message) {
    return res.status(400).json({ success: false, message: "All fields (name, email, and message) are required!" });
  }

  const query = "INSERT INTO contact_us(name, email, message) VALUES (?, ?, ?)";

  // Log the incoming data to verify the request
  console.log('Received data:', { name, email, message });

  db.query(query, [name, email, message], (err, result) => {
    if (err) {
      console.error("Error inserting data into database:", err);
      return res.status(500).json({ success: false, message: "Error saving data" });
    }
    res.json({ success: true, message: "Message saved successfully" });
  });
});

module.exports = router;
