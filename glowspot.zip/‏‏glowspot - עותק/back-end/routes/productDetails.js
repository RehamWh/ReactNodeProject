const express = require('express');
const router = express.Router();
const dbSingleton = require('../dbSingleton');
const db = dbSingleton.getConnection();

router.get('/:id', (req, res) => {
  const { id } = req.params;

  // Ensure that the ID is valid
  if (!id || isNaN(id)) {
    return res.status(400).json({ error: 'Invalid product ID' });
  }

  const query = 'SELECT id, name, price, description, image FROM products WHERE id = ?';
  db.query(query, [id], (err, results) => {
    if (err) {
      console.error('Database error:', err);
      return res.status(500).json({ error: 'Database error', details: err });
    }

    if (results.length === 0) {
      console.log('Product not found with ID:', id);
      return res.status(404).json({ message: 'Product not found' });
    }

    let product = results[0];

    // Ensure correct image URL format
    if (product.image) {
      if (!product.image.startsWith('http')) {
        // If image URL is relative, convert it to absolute
        product.image = `${req.protocol}://${req.get('host')}${product.image.startsWith('/') ? '' : '/'}${product.image}`;
      }
    } else {
      // Set a default image if no image exists
      product.image = 'https://via.placeholder.com/300'; // You can set this to any default image URL
    }

    res.json(product);
  });
});

module.exports = router;
