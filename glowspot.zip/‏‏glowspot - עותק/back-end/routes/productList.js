const express = require('express');
const router = express.Router();
const dbSingleton = require('../dbSingleton');
const db = dbSingleton.getConnection();
const cors = require('cors');
router.use(cors()); // Enable CORS for all origins

router.get('/', (req, res) => {
  const query = 'SELECT id, name, price, image FROM products';

  db.query(query, (err, results) => {
    if (err) {
      return res.status(500).json({ error: 'Database error', details: err });
    }
    if (results.length === 0) {
      return res.status(404).json({ message: 'No products found' });
    }

    // Format image URLs
    const formattedResults = results.map(product => {
      if (product.image) {
        product.image = `${req.protocol}://${req.get('host')}${product.image}`;
      }
      return product;
    });

    res.json(formattedResults);
  });
});

module.exports = router;

