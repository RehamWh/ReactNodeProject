// profileRoutes.js
const express = require('express');
const router = express.Router();
const dbSingleton = require('../dbSingleton');
const db = dbSingleton.getConnection();
const bcrypt = require("bcrypt");
const cors = require('cors');
router.use(cors()); // Enable CORS for all origins

// Update user profile
router.put('/updateMyProfile', (req, res) => {
  const { name, last_name, phone_number, email, date_of_birth, user_name } = req.body;

  // Ensure that the required fields are not empty
  if (!name || !last_name || !phone_number || !email || !date_of_birth || !user_name) {
    return res.status(400).json({ message: 'All fields are required' });
  }

  // Query to update user profile in the database
  const query = 'UPDATE users SET name = ?, last_name = ?, phone_number = ?, email = ?, date_of_birth = ?, user_name = ? WHERE email = ?';

  db.query(query, [name, last_name, phone_number, email, date_of_birth, user_name, email], (err, result) => {
    if (err) {
      console.error('Error updating profile:', err);
      return res.status(500).json({ message: 'Error updating profile' });
    }
    return res.json({ success: true, message: 'Profile updated successfully' });
  });
});

router.put('/updatepassword', (req, res) => {
  const { password_hash, newPassword, phone_number } = req.body;

  // Ensure that the required fields are provided
  if (!password_hash || !newPassword || !phone_number) {
    return res.status(400).json({ message: 'Current password, new password, and phone number are required' });
  }

  // Query to verify the current password
  const query = 'SELECT password_hash FROM users WHERE phone_number = ?';

  db.query(query, [phone_number], (err, result) => {
    if (err) {
      console.error('Error checking password:', err);
      return res.status(500).json({ message: 'Error checking password' });
    }

    if (result.length === 0) {
      return res.status(404).json({ message: 'User not found' });
    }

    const storedPasswordHash = result[0].password_hash;

    // Compare the entered current password with the stored password hash
    bcrypt.compare(password_hash, storedPasswordHash, (err, isMatch) => {
      if (err) {
        return res.status(500).json({ message: 'Error comparing passwords' });
      }

      if (!isMatch) {
        return res.status(400).json({ message: 'Current password is incorrect' });
      }

      // If passwords match, hash the new password
      bcrypt.hash(newPassword, 10, (err, hashedNewPassword) => {
        if (err) {
          return res.status(500).json({ message: 'Error hashing new password' });
        }

        // Update the password hash in the database
        const updateQuery = 'UPDATE users SET password_hash = ? WHERE phone_number = ?';
        db.query(updateQuery, [hashedNewPassword, phone_number], (err, result) => {
          if (err) {
            console.error('Error updating password:', err);
            return res.status(500).json({ message: 'Error updating password' });
          }
          return res.json({ success: true, message: 'Password updated successfully' });
        });
      });
    });
  });
});

module.exports = router;
