import React from 'react'
import '../styles/NavBar.css'

import { useNavigate } from "react-router-dom";

function Footer() {
  const navigate = useNavigate();

  return (
    <nav className="bottom-bar">

      <button className="homebutton" onClick={() => navigate("/home")}>Go to Home Page</button>
      <div className="myname" > By Reham Wahbi</div>
    </nav>
  )
}

export default Footer