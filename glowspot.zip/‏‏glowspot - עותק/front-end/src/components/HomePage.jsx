import React from 'react'
import ProductList from './ProductList';
import { Link } from 'react-router-dom'




function HomePage() {
  return (
    <div>
      <Link to="/productlist" className="btn">Products List</Link>
    </div>


  )
}

export default HomePage;