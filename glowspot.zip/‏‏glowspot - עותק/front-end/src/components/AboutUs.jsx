  import React from 'react'
  
  function AboutUs() {
    return (
      <div>
        <h2>About This Project</h2>
        <p>This project is built using React, React Router, and Axios.</p>
        <p>Contact: rwreham@gmail.com</p>
      </div>
    )
  }
  
  export default AboutUs