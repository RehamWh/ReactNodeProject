import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';


function EditProduct() {
  const { id } = useParams();
  const navigate = useNavigate();

  const [editedProduct, setEditedProduct] = useState(null);
  const [error, setError] = useState('');
  const [msg, setMsg] = useState('');
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    fetchData();
  }, [id]);

  const fetchData = () => {
    axios.get(`/product/${id}`)
      .then(res => {
        setEditedProduct(res.data[0]); // Assuming the API returns an array
        setLoading(false);
      })
      .catch(error => {
        console.error('Error fetching product data:', error);
        setError('Failed to fetch product data.');
        setLoading(false);
      });
  };
  const updateProduct = (productToSend) => {
    axios.put(`/product/${id}`, productToSend)
      .then(res => {
        console.log('Product updated:', res.data);
        setMsg('Product was updated successfully.');
        setTimeout(() => {
          setMsg('');
          navigate('/');
        }, 2000);
      })
      .catch(error => {
        console.error('Error:', error);
        setError('Failed to update the product.');
      });
  };
  const handleChange = (e) => {
    const { name, value } = e.target;
    setEditedProduct(prevProduct => ({
      ...prevProduct,
      [name]: value,
    }));
  };
  const cleanString = (str) => str.trim().replace(/\s+/g, ' ');

  const handleSubmit = (e) => {
    e.preventDefault();

    if (!editedProduct) return;
    const cleanedProduct = {
      name: cleanString(editedProduct.name),
      price: cleanString(editedProduct.price),
      description: cleanString(editedProduct.description),
    };
    if (!cleanedProduct.name || !cleanedProduct.price || !cleanedProduct.description) {
      setError('All fields are required.');
      return;
    }
    if (cleanedProduct.name.length < 3) {
      setError('Title must be at least 3 characters long.');
      return;
    }
    setError('');
    updateProduct(cleanedProduct);
  };

  if (loading) {
    return <div>Loading product data...</div>;
  }





  return (


    <div className='add-product'>
      <div className='msg'> {msg}</div>
      <h2> Edit Product</h2>
      {error && <p className='error-message'>{error}</p>}
      {msg && <p className="success-message">{msg}</p>}
      {editedProduct && (
        <form onSubmit={handleSubmit}>
          <div>
            <label >Name :</label>
            <input
              type="text"
              name="name"
              value={editedProduct.name}
              onChange={handleChange}
              required />

          </div>
          <div>
            <label >Price :</label>
            <input
              type="text"
              name="price"
              value={editedProduct.price}
              onChange={handleChange} required />

          </div>
          <div>
            <label >Description :</label>
            <input
              type="text"
              name="description"
              value={editedProduct.description}
              onChange={handleChange} required /></div>


          <div>
            <label>Upload Image</label>
            <input
              type='file'
              name='image/**'
              valse={editedProduct.image}
              onChange={handleChange} />
          </div>


          <button type="submit" >Save</button>
        </form>
      )}
    </div>
  );

}



export default EditProduct;