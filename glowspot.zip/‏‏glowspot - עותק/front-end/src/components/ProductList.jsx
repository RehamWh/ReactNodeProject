import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';
import "../styles/ProductList.module.css";

function ProductList() {
  const [products, setProducts] = useState([]);
  const [msg, setMsg] = useState('');

  // Fetch products when the component mounts
  useEffect(() => {
    let isMounted = true; // Prevents state update on unmounted component
    const fetchData = async () => {
      try {
        const res = await axios.get('http://localhost:5000/productlist'); // ✅ Correct API endpoint
        if (isMounted) setProducts(res.data);
      } catch (error) {
        console.error('Error fetching products:', error.response?.data?.message || error.message);
      }
    };

    fetchData();
    return () => { isMounted = false; }; // Cleanup function
  }, []);

  // Delete product
  const handleDelete = async (product) => {
    if (window.confirm(`Are you sure you want to delete product: ${product.name}?`)) {
      try {
        await axios.delete(`http://localhost:5000/productlist/${product.id}`); // ✅ Correct delete request
        setProducts(products.filter(p => p.id !== product.id));
        setMsg('Product was deleted');
        setTimeout(() => setMsg(''), 2000);
      } catch (error) {
        console.error('Error deleting product:', error.response?.data?.message || error.message);
      }
    }
  };

  return (
    <div className="main">
      <section className="products">
        <div className="container">
          <h1 className="product-list-title">Products:</h1>
          <div className="d-flex">
            <Link to="/addproduct" className="btn">New Product</Link>
          </div>
          {msg && <div className="msg">{msg}</div>}
          <div className="products-container">
            {products.length > 0 ? (
              products.map((product) => (
                <div key={product.id} className="product-card">
                  <img src={product.image} alt={product.name} className="product-image" />
                  <h2 className="product-name">{product.name}</h2>
                  <Link to={`/productdetails/${product.id}`} className="view-button">View</Link>
                  <Link to={`/editproduct/${product.id}`} className="edit-button">Edit</Link>
                  <button className="delete-button" onClick={() => handleDelete(product)}>Delete</button>
                </div>
              ))
            ) : (
              <p>No products available.</p>
            )}
          </div>
        </div>
      </section>
    </div>
  );
}

export default ProductList;
