import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Link } from 'react-router-dom';
import '../styles/LogIn.css';

function LogIn() {
  const [user_name, setUser_name] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);  // Add loading state
  const [error, setError] = useState(''); // Error message for better feedback

  const navigate = useNavigate();

  const handleSubmit = async (event) => {
    event.preventDefault();

    setLoading(true);  // Set loading to true when making request
    setError('');  // Clear previous error

    try {
      const res = await fetch('http://localhost:5000/login', {
        method: 'POST',
        body: JSON.stringify({ user_name, password }),
        headers: {
          'Content-Type': 'application/json',
        },
      });

      if (!res.ok) {
        throw new Error('Failed to log in');
      }

      const data = await res.json();

      if (data && data.user_name === user_name) {
        sessionStorage.setItem('phone', data.phone_number);
        sessionStorage.setItem('name', data.name);
        sessionStorage.setItem('familyName', data.last_name);
        sessionStorage.setItem('email', data.email);
        sessionStorage.setItem('date_of_birth', data.date_of_birth);
        sessionStorage.setItem('user_name', data.user_name);

        navigate('/home');
      } else {
        setError('Wrong username or password');  // Set specific error message
      }
    } catch (err) {
      setError('Error logging in, please try again.');  // Set specific error message
    } finally {
      setLoading(false);  // Set loading to false after request completes
    }
  };

  return (
    <form className='login' onSubmit={handleSubmit}>
      <h1 className='h1'>Log In</h1>

      {error && <p className="error-message">{error}</p>}  {/* Display error message */}

      <div className='inputs'>
        <label className='username'>
          Username:
          <input
            className='input'
            type='text'
            value={user_name}
            onChange={(e) => setUser_name(e.target.value)}
          />
        </label>
        <p className='login_p'></p>
        <label className='password'>
          Password:
          <input
            className='input'
            type='password'
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </label>
      </div>
      <p className='login_p'></p>
      <button className='button' type='submit' disabled={loading}>  {/* Disable button when loading */}
        {loading ? 'Logging In...' : 'Log In'}  {/* Show loading text */}
      </button>
      <p className='login_p'></p>
      <p className='p'>
        Don't have an account?{' '}
        <Link className='link' to='/signup'>
          Sign up here
        </Link>
        .
      </p>
      <p className='login_p'></p>

      <p className='p'>
        Forgot password?{' '}
        <Link className='link' to='/reset-password'>
          Reset Password
        </Link>
      </p>
    </form>
  );
}

export default LogIn;
