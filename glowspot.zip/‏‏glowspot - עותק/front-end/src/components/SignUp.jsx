import React from 'react'
import { useState } from 'react';
import { useNavigate } from 'react-router-dom'
import { Link } from 'react-router-dom'


function SignUp() {
  const [name, setName] = useState('');
  const [last_name, setLast_name] = useState('');
  const [phone_number, setPhone_number] = useState('');
  const [email, setEmail] = useState('');
  const [user_role] = useState('user');
  const [date_of_birth, setDate_of_birth] = useState('');
  const [user_name, setUser_name] = useState('');
  const [password, setpassword] = useState('');
  const [confirmpassword, setConfirmpassword] = useState('');
  const navigate = useNavigate();

  const handleSubmit = (event) => {
    event.preventDefault();

    // Check if passwords match on the frontend
    if (password !== confirmpassword) {
      alert("Password and confirmation do not match");
      return;
    }

    fetch('http://localhost:5000/signup', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        name: name,
        last_name: last_name,
        phone_number: phone_number,
        email: email,
        user_role: user_role,
        date_of_birth: date_of_birth,
        user_name: user_name,
        password: password,
        confirmpassword: confirmpassword,  // Pass this to the backend
      }),
    })
      .then((res) => res.json())
      .then((res) => {
        console.log(res.message);
        if (res.message === 'Password and confirmation do not match') {
          alert('Password and confirmation do not match');
        } else if (res.message === 'User added!') {
          navigate('/');  // Redirect to login page after successful signup
        }
      })
      .catch((err) => {
        console.log(err);
      });
  };


  return (
    <div className='first'>
      <div>
        <h1 className='signup'>Sign Up</h1>
        <form className='f1'>
          <div className='user'>
            <label htmlFor='username'>Enter Name</label>
            <input
              type='text'
              placeholder='Enter Name'
              name='name'
              value={name}
              onChange={(event) => {
                setName(event.target.value);
              }}
            />
          </div>
          <div className='user'>
            <label htmlFor='username'>Enter Last Name</label>
            <input
              type='text'
              placeholder='Enter Last Name'
              name='last_name'
              value={last_name}
              onChange={(event) => {
                setLast_name(event.target.value);
              }}
            />
          </div>

          <div className='user'>
            <label htmlFor='username'>Enter Phone Number</label>
            <input
              type='text'
              placeholder='Enter Phone_Number'
              name='phone_number'
              value={phone_number}
              onChange={(event) => {
                setPhone_number(event.target.value);
              }}
            />
          </div>
          <div className='user'>
            <label htmlFor='email'>Email</label>
            <input
              type='email'
              placeholder='Enter Email'
              name='email'
              value={email}
              onChange={(event) => {
                setEmail(event.target.value);
              }}
            />
          </div>
          <div className='user'>
            <label htmlFor='date'>Enter Date Of Birth</label>
            <input
              type='date'
              placeholder='Enter Date Of Birth'
              name='date_of_birth'
              value={date_of_birth}
              onChange={(event) => {
                setDate_of_birth(event.target.value);
              }}
            />
          </div>
          <div className='user'>
            <label htmlFor='username'>Enter User Name</label>
            <input
              type='text'
              placeholder='Enter User Name'
              name='username'
              value={user_name}
              onChange={(event) => {
                setUser_name(event.target.value);
              }}
            />
          </div>
          <div className='user'>
            <label htmlFor='password'>Enter Password</label>
            <input
              type='password'
              placeholder='Enter Password'
              name='password'
              value={password}
              onChange={(event) => {
                setpassword(event.target.value);
              }}
            />
          </div>
          <div className='user'>
            <label htmlFor='password'>Confirm Password</label>
            <input
              type='password'
              placeholder='Enter Comfirmation Password'
              name='confirmationpassword'
              value={confirmpassword}
              onChange={(event) => {
                setConfirmpassword(event.target.value);
              }}
            />
          </div>
          <button className='btn' type='submit' onClick={handleSubmit}>
            Sign Up
          </button>
        </form>
      </div>
      <p className='myp'></p>
      <p className='li'>
        already have an account?, go back to <Link to='/'>Login Page</Link>
      </p>
    </div>
  );
}

export default SignUp