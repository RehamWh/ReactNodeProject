import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

function UserProfile() {
  const navigate = useNavigate(); // Initialize useNavigate hook

  const [name, setName] = useState(sessionStorage.getItem('name'));
  const [last_name, setLast_name] = useState(sessionStorage.getItem('familyName'));
  const [phone_number, setPhone_number] = useState(sessionStorage.getItem('phone'));
  const [email, setEmail] = useState(sessionStorage.getItem('email'));
  const [date_of_birth, setDate_of_birth] = useState(sessionStorage.getItem('date_of_birth'));
  const [user_name, setUser_name] = useState(sessionStorage.getItem('user_name'));

  const [password, setPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');

  // Update user profile
  const handleUpdate = (event) => {
    event.preventDefault(); // Prevent default form submission
    fetch('http://localhost:5000/myProfile/updateMyProfile', {
      method: 'PUT', // Use PUT for updates
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        name: name,
        last_name: last_name,
        phone_number: phone_number,
        email: email,
        date_of_birth: date_of_birth,
        user_name: user_name,
      }),
    })
      .then((res) => {
        if (res.ok) {
          console.log('Profile updated successfully');
          navigate('/profile'); // Redirect to the profile page after successful update
        } else {
          console.log('Error updating the profile');
        }
      })
      .catch((err) => {
        console.log(err);
      });
  };

  // Change password
  const handleNewPassword = (event) => {
    event.preventDefault(); // Prevent default form submission
    if (!password || !newPassword) {
      console.log("Both password and new password are required");
      return;
    }
    fetch('http://localhost:5000/myProfile/updatepassword', {
      method: 'PUT', // Use PUT for password update
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        password: password,
        newPassword: newPassword,
        phone_number: phone_number,
      }),
    })
      .then((res) => {
        if (res.ok) {
          console.log('Password changed successfully');
          navigate('/profile'); // Redirect to the profile page after successful password change
        } else {
          console.log('Error changing password');
        }
      })
      .catch((err) => {
        console.log('Error changing password', err);
      });
  };

  return (
    <div className='first'>
      <div>
        <form className='f1'>
          <h1 className='my_profile'>My Profile</h1>
          <div className='n1'>
            <label htmlFor='name'>Name</label>
            <input
              type='text'
              placeholder='Name'
              name='name'
              value={name}
              onChange={(event) => setName(event.target.value)}
            />
          </div>
          <div className='lastname'>
            <label htmlFor='lastname'>Last Name</label>
            <input
              type='text'
              placeholder='Last Name'
              name='last_name'
              value={last_name}
              onChange={(event) => setLast_name(event.target.value)}
            />
          </div>

          <div className='phone'>
            <label htmlFor='phone'>Phone Number</label>
            <input
              type='text'
              placeholder='Phone Number'
              name='phone_number'
              value={phone_number}
              onChange={(event) => setPhone_number(event.target.value)} // Allow editing
            />
          </div>
          <div className='email'>
            <label htmlFor='email'>Email</label>
            <input
              type='email'
              placeholder='Email'
              name='email'
              value={email}
              onChange={(event) => setEmail(event.target.value)}
            />
          </div>
          <div className='date'>
            <label htmlFor='date'>Date Of Birth</label>
            <input
              type='text'
              placeholder='Date Of Birth'
              name='date_of_birth'
              value={date_of_birth}
              onChange={(event) => setDate_of_birth(event.target.value)}
            />
          </div>
          <div className='styles.username'>
            <label htmlFor='username'>Username</label>
            <input
              type='text'
              placeholder='Username'
              name='username'
              value={user_name}
              onChange={(event) => setUser_name(event.target.value)}
            />
          </div>
          <div className='btn'>
            <button type='button' onClick={handleUpdate}> {/* Change to type='button' */}
              Update Profile
            </button>
          </div>
        </form>

        <form className='updatepass'>
          <h1 className='newpass'>Change Password</h1>
          <div className='currentpass'>
            <label htmlFor='password'>Enter Current Password</label>
            <input
              type='password'
              placeholder='Current Password'
              name='password'
              value={password}
              onChange={(event) => setPassword(event.target.value)}
            />
          </div>
          <div className='newpass'>
            <label htmlFor='newpassword'>Enter New Password</label>
            <input
              type='password'
              placeholder='New Password'
              name='newpassword'
              value={newPassword}
              onChange={(event) => setNewPassword(event.target.value)}
            />
          </div>
          <button type='button' onClick={handleNewPassword}> {/* Change to type='button' */}
            Update Password
          </button>
        </form>
      </div>
    </div>
  );
}

export default UserProfile;
