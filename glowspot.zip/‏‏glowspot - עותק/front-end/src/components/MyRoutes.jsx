import React from 'react'
import { Routes, Route } from "react-router-dom";
import HomePage from './HomePage';
import AboutUs from './AboutUs';
import ContactUs from './ContactUs';
import NavBar from './NavBar';
import UserProfile from './UserProfile';
import Footer from './Footer';
import ProductDetails from './ProductDetails';
import LogIn from './LogIn';
import SignUp from './SignUp';
import AddProduct from './AddProduct';
import EditProduct from './EditProduct';
import ProductList from './ProductList';

function MyRoutes() {
  return (
    <>
      <NavBar />
      <Routes>
        <Route path='/' element={<LogIn />} />
        <Route path="/home" element={<HomePage />} />
        <Route path="/about" element={<AboutUs />} />
        <Route path="/contact" element={<ContactUs />} />
        <Route path="/user/:id" element={<UserProfile />} />
        <Route path="signup" element={<SignUp />} />
        <Route path="/productdetails/:id" element={<ProductDetails />} />
        <Route path="/profile/:id" element={<UserProfile />} />
        <Route path="/addproduct" element={<AddProduct />} />
        <Route path="/editproduct/:id" element={<EditProduct />} />
        <Route path="/productlist" element={<ProductList />} />

      </Routes >
      <Footer />
    </>

  )
}

export default MyRoutes