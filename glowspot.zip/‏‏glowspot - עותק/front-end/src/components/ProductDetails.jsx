import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import axios from 'axios';

function ProductDetails() {
  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const { id } = useParams();

  useEffect(() => {
    const fetchData = async () => {
      try {
        console.log('Fetching product with ID:', id);
        const res = await axios.get(`http://localhost:5000/productdetails/${id}`);
        console.log('API Response:', res.data); // Debugging API response

        if (res.data && Object.keys(res.data).length > 0) {
          setProduct(res.data);
          setError(null);
        } else {
          setProduct(null);
          setError('Product not found.');
        }
      } catch (err) {
        console.error('Error fetching product:', err);
        setError('Failed to fetch product.');
        setProduct(null);
      } finally {
        setLoading(false);
      }
    };

    if (id) {
      fetchData();
    }
  }, [id]);

  if (loading) return <div className="container"><p>Loading product...</p></div>;
  if (error) return <div className="container"><p>{error}</p></div>;

  return (
    <div className="main">
      <section className="product">
        {product ? (
          <div className="container">
            <div className="single-product">
              <h1 className="product-name">{product.name}</h1>
              <img
                src={product.image || 'https://via.placeholder.com/300'}  // Default image if product doesn't have one
                alt={product.name}
                className="product-image"
                onError={(e) => { e.target.src = 'https://via.placeholder.com/300'; }}  // Fallback image in case of broken image link
              />
              <p className="product-description">{product.description}</p>
            </div>
          </div>
        ) : (
          <div className="container"><p>Product does not exist.</p></div>
        )}
      </section>
    </div>
  );
}

export default ProductDetails;
