import React from 'react'
import { Link } from 'react-router-dom'
import '../styles/NavBar.css'
import logo from '../images/logo.png'

function NavBar() {
  return (
    <nav className='navbar'>
      <img src={logo} alt='Logo' className='logo' />
      <div className='title'>Glow Spot</div>
      <Link className="nav-link" to="/home" >Home</Link>
      <Link className="nav-link" to="/about">About Us</Link>
      <Link className="nav-link" to="/contact">Contact Us</Link>
      <div className="myname" > By Reham Wahbi</div>
    </nav>
  )
}

export default NavBar