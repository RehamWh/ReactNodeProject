import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

const cleanString = (str) => str.trim().replace(/\s+/g, ' ');

function AddProduct() {
  const [msg, setMsg] = useState('');
  const [newProduct, setNewProduct] = useState({
    name: '',
    price: '',
    description: '',
  });
  const [imageFile, setImageFile] = useState(null);
  const [preview, setPreview] = useState(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleChange = (e) => {
    const { name, value } = e.target;
    setNewProduct((prevProduct) => ({
      ...prevProduct,
      [name]: value,
    }));
  };

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      const validTypes = ['image/jpeg', 'image/png', 'image/webp'];
      if (!validTypes.includes(file.type)) {
        setError('Invalid file type. Please upload a JPEG, PNG, or WEBP image.');
        return;
      }
      if (file.size > 2 * 1024 * 1024) {
        setError('File size must be less than 2MB.');
        return;
      }
      setImageFile(file);
      setPreview(URL.createObjectURL(file));
      setError('');
    }
  };

  const addProduct = async () => {
    try {
      setLoading(true);
      const formData = new FormData();
      formData.append('name', cleanString(newProduct.name));
      formData.append('price', newProduct.price);
      formData.append('description', cleanString(newProduct.description));
      if (imageFile) {
        formData.append('image', imageFile);
      }

      const res = await axios.post('http://localhost:5000/addproduct', formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });

      setMsg('✅ Product added successfully!');
      setTimeout(() => {
        setMsg('');
        navigate('/home');
      }, 2000);
    } catch (error) {
      console.error('Error:', error.response || error);
      setError(error.response?.data?.message || 'Failed to add product. Try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!newProduct.name || !newProduct.price || !newProduct.description) {
      setError('Please fill in all fields.');
      return;
    }
    if (newProduct.name.length < 5) {
      setError('The name must be at least 5 characters long.');
      return;
    }
    if (!/^\d+(\.\d{1,2})?$/.test(newProduct.price) || newProduct.price <= 0) {
      setError('Enter a valid price (e.g., 10.99).');
      return;
    }
    setError('');
    await addProduct();
  };

  return (
    <div className='add-product'>
      {msg && <div className='success-message'>{msg}</div>}
      {error && <div className='error-message'>{error}</div>}
      <h2>Add a New Product</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label>Name:</label>
          <input type="text" name="name" value={newProduct.name} onChange={handleChange} required />
        </div>
        <div>
          <label>Price:</label>
          <input type="number" name="price" step="0.01" value={newProduct.price} onChange={handleChange} required />
        </div>
        <div>
          <label>Description:</label>
          <input type="text" name="description" value={newProduct.description} onChange={handleChange} required />
        </div>
        <div>
          <label>Upload Image:</label>
          <input type="file" name="image" accept="image/*" onChange={handleFileChange} />
          {preview && <img src={preview} alt="Preview" style={{ width: '100px', marginTop: '10px' }} />}
        </div>
        <button type="submit" disabled={loading || !newProduct.name || !newProduct.price || !newProduct.description}>
          {loading ? 'Adding...' : 'Add Product'}
        </button>
      </form>
    </div>
  );
}

export default AddProduct;
